import { crearArray,mostrarArray } from './funcion.js';

let num1 =9;
let num2= 2;
let num3=5;

crearArray(num1,num2,num3);
mostrarArray();